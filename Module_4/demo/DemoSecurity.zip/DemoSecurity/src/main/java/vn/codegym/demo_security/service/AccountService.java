package vn.codegym.demo_security.service;

import vn.codegym.demo_security.model.Account;

public interface AccountService {
    public void save(Account account);
}
