package Repository;

public interface DungSi {
    String thucHienNhiemVu();
}
