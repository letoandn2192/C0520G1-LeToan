package model.DependencyInjection;

public class TimMeoMatTich implements NhiemVu {


    public TimMeoMatTich() {

    }

    @Override
    public String ThucHien() {
        return "Chạy khắp nơi tìm mèo";
    }
}
