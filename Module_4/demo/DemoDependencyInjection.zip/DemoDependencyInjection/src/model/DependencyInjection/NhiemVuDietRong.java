package model.DependencyInjection;

public class NhiemVuDietRong implements NhiemVu {

    public NhiemVuDietRong() {}

    @Override
    public String ThucHien() {
        return "Dùng thuốc độc để diệt rồng";
    }
}
