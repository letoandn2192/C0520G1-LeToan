package model.DependencyInjection;

public interface NhiemVu {
    String ThucHien();
}

