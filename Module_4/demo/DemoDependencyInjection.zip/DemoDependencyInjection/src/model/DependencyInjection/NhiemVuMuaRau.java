package model.DependencyInjection;

public class NhiemVuMuaRau implements NhiemVu {

    public NhiemVuMuaRau() {}

    @Override
    public String ThucHien() {
       return  "Ra chợ mua rau dền";
    }

}
