package model.NoDependencyInjection;

public class NhiemVuDietRong {

    public String thucHien(){
        return "Dùng Gươm và Khiên để diệt rồng";
    }
}
