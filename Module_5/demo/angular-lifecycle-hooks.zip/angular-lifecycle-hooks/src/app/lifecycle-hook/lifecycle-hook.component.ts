import {Component, OnInit, OnDestroy, OnChanges, Input, SimpleChanges, AfterContentChecked, AfterContentInit} from '@angular/core';

@Component({
  selector: 'app-lifecycle-hook',
  templateUrl: './lifecycle-hook.component.html',
  styleUrls: ['./lifecycle-hook.component.css']
})
export class LifecycleHookComponent implements OnInit, OnDestroy, OnChanges, AfterContentChecked, AfterContentInit {

  @Input('result') result_html: number;
  constructor() { }
  isDisplay:boolean = false;

  ngOnInit(): void {
    console.log("ngOnInit: LifecycleHookComponent")
  }

  ngOnDestroy(): void {
    console.log("ngOnDestroy: LifecycleHookComponent")
  }

  onClick() {
    this.isDisplay = !this.isDisplay;
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges: LifecycleHookComponent");
    console.log(changes.result_html.previousValue);
  }


  ngAfterContentInit(): void {
    console.log("ngAfterContentInit: LifecycleHookComponent");
  }

  ngAfterContentChecked(): void {
    console.log("ngAfterContentChecked: LifecycleHookComponent");
  }


  // ngOnChanges(): void {
  //   console.log("ngOnChanges: LifecycleHookComponent")
  // }


}
