import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-lifecycle-hooks';
  isDisplay:boolean = true;
  a:number;
  b:number;
  total:number = 0;

  onToogle() {
    this.isDisplay = !this.isDisplay;
  }

  sum() {
    this.total = this.a + this.b;
  }
}
